package com.equipoQ.alquilerQuinchos.Enumeraciones;

public enum Rol {

CLIENTE,
PROPIETARIO,
ADMIN;


}
